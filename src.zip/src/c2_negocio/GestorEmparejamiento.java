package c2_negocio;

import c1_modelo.Adoptante;
import c1_modelo.Animal;

public class GestorEmparejamiento {

    public int calcularMatch(Adoptante adoptante, Animal animal) {
        // --- FASE 1: VETOS ABSOLUTOS (0%) ---

        // 1. Historial negativo
        if (adoptante.isVetado()) {
            return 0;
        }

        // 2. Energía vs. Paseo: Un perro muy activo necesita mínimo 1 hora (60 mins) de paseo
        if (animal.getNivelEnergia() >= 4 && adoptante.getMinutosPaseoDiario() < 60) {
            return 0;
        }

        // 3. Condición médica vs. Presupuesto
        if (animal.tieneCondicionMedica() && adoptante.getPresupuestoMensual() < 100.0) {
            return 0;
        }

        // 4. Soledad Extrema (Fisiológico)
        if (adoptante.getHorasFueraCasa() >= 10) {
            return 0;
        }

        // --- FASE 2: PENALIZACIONES (Puntaje inicial: 100) ---
        int puntaje = 100;

        // A. Penalización por estabilidad (Arriendo)
        if (!adoptante.isViviendaPropia()) {
            puntaje -= 15;
        }

        // B. Penalización por Espacio y Tamaño
        if (adoptante.getTipoVivienda().equals("Departamento")) {
            if (animal.getTamano().equals("Grande")) {
                puntaje -= 20; // Castigo fuerte si es departamento + grande
            } else {
                puntaje -= 5;  // Castigo leve si es mediano/pequeño
            }
        }

        // C. Penalización por soledad moderada
        if (adoptante.getHorasFueraCasa() > 7) {
            puntaje -= 10;
        }

        // D. Penalización por inexperiencia con perros activos
        if (!adoptante.tieneExperiencia() && animal.getNivelEnergia() > 3) {
            puntaje -= 15;
        }

        return puntaje;
    }
}